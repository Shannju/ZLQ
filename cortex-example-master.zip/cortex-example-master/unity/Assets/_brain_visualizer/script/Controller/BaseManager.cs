﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace dirox.emotiv.controller
{
    public abstract class BaseManager : BaseCanvasView
    {
    }
}