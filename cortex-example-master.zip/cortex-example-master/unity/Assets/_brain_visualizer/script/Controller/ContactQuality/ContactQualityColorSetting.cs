﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace dirox.emotiv.controller
{
    public class ContactQualityColorSetting : MonoBehaviour
    {
        public Color[] colors;
    }
}