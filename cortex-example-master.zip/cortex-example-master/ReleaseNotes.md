# Release Notes

## 30th November, 2022
- Add Emotiv's self-signed certificate rootCA.pem
- Update python example to use the Emotiv's self-signed certificate when open a secure Websocket connection to Emotiv Cortex Websocket
- Replace Newtonsoft.Json.12.0.1 csharp library by new version Newtonsoft.Json.13.0.1

## Before 30th November, 2022
- Introduce and update cpp-qt, python, csharp, unity, nodejs examples to show how to work with Emotiv Cortex.

