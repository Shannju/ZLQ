# README

## 运行方式

**在安装python3的环境下**打开

cmd终端下执行 python TDinput.py

打开TD工程NewProject.5.toe



成功运行示例：

![1717265575345](README/1717265575345.png)

成功运行视频：

\ZLQ\TDinputTst\运行样例.mp4

